import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isSignUp = false;
  bool _hidePassword = true;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _continue() {
    AppState.instance.userName = _nameController.text.trim().isEmpty
        ? 'Guest User'
        : _nameController.text.trim();
    Navigator.pushNamed(context, '/destination');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const BackButton(), title: const Text('SafeNav')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shield_outlined, color: AppColors.blue, size: 42),
              const SizedBox(height: 18),
              Text(_isSignUp ? 'Create your account' : 'Welcome back',
                style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w700, color: AppColors.navy)),
              const SizedBox(height: 6),
              const Text('Plan safer routes and keep your trip connected.',
                style: TextStyle(fontSize: 14, color: AppColors.muted)),
              const SizedBox(height: 26),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: AppColors.blueLight, borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  _modeButton('Sign in', !_isSignUp, () => setState(() => _isSignUp = false)),
                  _modeButton('Sign up', _isSignUp, () => setState(() => _isSignUp = true)),
                ]),
              ),
              const SizedBox(height: 22),
              if (_isSignUp) ...[
                TextField(controller: _nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline))),
                const SizedBox(height: 14),
              ],
              TextField(controller: _phoneController, keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Email or phone number', prefixIcon: Icon(Icons.person_outline))),
              const SizedBox(height: 14),
              TextField(controller: _passwordController, obscureText: _hidePassword,
                decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline),
                  suffixIcon: IconButton(icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                    onPressed: () => setState(() => _hidePassword = !_hidePassword))),),
              const SizedBox(height: 22),
              SizedBox(width: double.infinity, child: ElevatedButton(
                onPressed: _continue,
                child: Text(_isSignUp ? 'Create account' : 'Sign in'),
              )),
              const SizedBox(height: 18),
              const Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('OR', style: TextStyle(color: AppColors.muted, fontSize: 12))), Expanded(child: Divider())]),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: OutlinedButton.icon(
                onPressed: _continue,
                icon: const Icon(Icons.explore_outlined),
                label: const Text('Continue as guest'),
                style: OutlinedButton.styleFrom(foregroundColor: AppColors.blue, padding: const EdgeInsets.symmetric(vertical: 14),
                  side: const BorderSide(color: AppColors.cardBorder), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              )),
              const SizedBox(height: 20),
              const Text('By continuing, you agree to use location and emergency features responsibly.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _modeButton(String label, bool selected, VoidCallback onTap) => Expanded(
    child: TextButton(
      onPressed: onTap,
      style: TextButton.styleFrom(
        backgroundColor: selected ? Colors.white : Colors.transparent,
        foregroundColor: selected ? AppColors.blue : AppColors.muted,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
    ),
  );
}
